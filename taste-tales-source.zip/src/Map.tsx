import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { Story } from "./data";
export default function FoodMap({
  stories,
  onSelect,
  onPick,
  selected,
}: {
  stories: Story[];
  onSelect?: (id: string) => void;
  onPick?: (lat: number, lng: number) => void;
  selected?: [number, number];
}) {
  const el = useRef<HTMLDivElement>(null);
  const map = useRef<L.Map | null>(null);
  const layer = useRef<L.LayerGroup | null>(null);
  const select = useRef(onSelect);
  const pick = useRef(onPick);
  select.current = onSelect;
  pick.current = onPick;
  useEffect(() => {
    if (!el.current) return;
    const m = L.map(el.current, {
      scrollWheelZoom: false,
      minZoom: 2,
      worldCopyJump: true,
    }).setView([18, 35], 2);
    map.current = m;
    layer.current = L.layerGroup().addTo(m);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution:
        '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    }).addTo(m);
    m.on("click", (e: L.LeafletMouseEvent) =>
      pick.current?.(
        e.latlng.lat,
        ((((e.latlng.lng + 180) % 360) + 360) % 360) - 180,
      ),
    );
    const observer = new ResizeObserver(() => m.invalidateSize());
    observer.observe(el.current);
    return () => {
      observer.disconnect();
      m.remove();
      map.current = null;
    };
  }, []);
  useEffect(() => {
    const m = map.current;
    const group = layer.current;
    if (!m || !group) return;
    group.clearLayers();
    const located = stories.filter((s): s is Story & { lat: number; lng: number } =>
      typeof s.lat === "number" && typeof s.lng === "number" &&
      Number.isFinite(s.lat) && Number.isFinite(s.lng) &&
      Math.abs(s.lat) <= 90 && Math.abs(s.lng) <= 180,
    );
    located.forEach((s) => {
      const marker = L.marker([s.lat, s.lng], {
        icon: L.divIcon({
          className: "food-pin",
          html: "<span>♥</span>",
          iconSize: [36, 42],
          iconAnchor: [18, 42],
        }),
        title: `${s.dish} — ${s.place}`,
        keyboard: true,
      }).addTo(group);
      const label = document.createElement("span");
      label.textContent = s.dish;
      marker.bindTooltip(label);
      marker.on("click", () => select.current?.(s.id));
    });
    if (selected) {
      L.marker(selected).addTo(group);
      m.setView(selected, 7);
    } else if (located.length === 1)
      m.setView([located[0].lat, located[0].lng], 5);
    else if (located.length > 1)
      m.fitBounds(
        L.latLngBounds(located.map((s) => [s.lat, s.lng] as [number, number])),
        { padding: [45, 45], maxZoom: 5 },
      );
  }, [stories, selected]);
  return (
    <div
      ref={el}
      className="food-map"
      aria-label={
        onPick
          ? "Choose a memory location on the map"
          : "Interactive map of food memories"
      }
    />
  );
}
