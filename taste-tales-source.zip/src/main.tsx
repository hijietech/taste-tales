import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./style.css";
import { registerSW } from "virtual:pwa-register";

// Refresh an older app shell when a new worker takes control. Never interrupt
// a contributor who may have an unsaved story in the form.
if ("serviceWorker" in navigator) {
  let controlled = !!navigator.serviceWorker.controller;
  let refreshed = false;
  let updatePending = false;
  const refreshWhenSafe = () => {
    if (updatePending && !refreshed && !location.hash.startsWith("#/share")) {
      refreshed = true;
      location.reload();
    }
  };
  navigator.serviceWorker.addEventListener("controllerchange", () => {
    if (controlled) {
      updatePending = true;
      refreshWhenSafe();
    }
    controlled = true;
  });
  window.addEventListener("hashchange", refreshWhenSafe);
  registerSW({
    immediate: true,
    onRegisteredSW(_url, registration) {
      const check = () => {
        void registration?.update().catch(() => {});
      };
      check();
      document.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "visible") check();
      });
    },
  });
}
createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
