import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Camera,
  Check,
  ChefHat,
  Clock,
  Compass,
  Download,
  Heart,
  Home,
  MapPin,
  Menu,
  Plus,
  Search,
  Sparkles,
  Users,
  UtensilsCrossed,
  X,
} from "lucide-react";
import { seeds, themes, filterStories, type Story } from "./data";
import { getStories, saveStory, deleteStory, photoData } from "./storage";
import FoodMap from "./Map";
const go = (path: string) => {
  window.location.hash = path;
};
function useRoute() {
  const [path, setPath] = useState(location.hash.slice(1) || "/");
  useEffect(() => {
    const fn = () => {
      setPath(location.hash.slice(1) || "/");
      window.scrollTo(0, 0);
    };
    window.addEventListener("hashchange", fn);
    return () => window.removeEventListener("hashchange", fn);
  }, []);
  return path;
}
function Photo({
  src,
  alt,
  ...props
}: React.ImgHTMLAttributes<HTMLImageElement>) {
  return (
    <img
      src={src}
      alt={alt}
      {...props}
      onError={(e) => {
        e.currentTarget.style.visibility = "hidden";
        e.currentTarget.parentElement?.classList.add("photo-fallback");
      }}
    />
  );
}
function StoryCard({
  story,
  large = false,
}: {
  story: Story;
  large?: boolean;
}) {
  return (
    <button
      className={`story-card ${large ? "large" : ""}`}
      onClick={() => go("/story/" + story.id)}
    >
      <div className="card-photo">
        <Photo src={story.image} alt={story.dish} loading="lazy" />
        <span className="photo-tag">{story.theme}</span>
        <span className="photo-arrow">
          <ArrowRight size={19} />
        </span>
      </div>
      <div className="card-copy">
        <span className="location">
          <MapPin size={13} />
          {story.place}
        </span>
        <h3>{story.title}</h3>
        <p>{story.body.split("\n")[0]}</p>
        <span className="card-credit">
          {story.demo ? "Illustrative story" : `Shared by ${story.author}`}
        </span>
      </div>
    </button>
  );
}
export default function App() {
  const path = useRoute();
  const [saved, setSaved] = useState<Story[]>([]);
  const [loadError, setLoadError] = useState("");
  const [notice, setNotice] = useState("");
  const [query, setQuery] = useState("");
  const [theme, setTheme] = useState("All memories");
  const [menu, setMenu] = useState(false);
  useEffect(() => {
    getStories()
      .then(setSaved)
      .catch(() =>
        setLoadError(
          "Your browser could not open local storage. Browsing is available, but saving may not work.",
        ),
      );
  }, []);
  useEffect(() => {
    setMenu(false);
  }, [path]);
  useEffect(() => {
    if (!notice) return;
    const t = setTimeout(() => setNotice(""), 6000);
    return () => clearTimeout(t);
  }, [notice]);
  const stories = useMemo(
    () => [...saved.slice().reverse(), ...seeds],
    [saved],
  );
  const filtered = useMemo(
    () => filterStories(stories, query, theme),
    [stories, query, theme],
  );
  const selected = stories.find((s) => s.id === path.split("/")[2]);
  const onSaved = (story: Story) => {
    setSaved((prev) => [...prev, story]);
    setNotice("Memory saved on this device.");
    go("/story/" + story.id);
  };
  const explore = path === "/map";
  const search = (
    <form
      className="search"
      onSubmit={(e) => {
        e.preventDefault();
        go("/home");
      }}
    >
      <Search size={19} />
      <input
        aria-label="Search stories"
        placeholder="A place, a dish, a memory…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      {query && (
        <button
          type="button"
          className="icon-button"
          aria-label="Clear search"
          onClick={() => setQuery("")}
        >
          <X size={16} />
        </button>
      )}
      <button className="round-button" aria-label="Search">
        <ArrowRight size={18} />
      </button>
    </form>
  );
  const chips = (
    <div className="chips" aria-label="Filter by memory theme">
      {themes.map((t) => (
        <button
          key={t}
          className={theme === t ? "active" : ""}
          aria-pressed={theme === t}
          onClick={() => setTheme(t)}
        >
          {t}
        </button>
      ))}
    </div>
  );
  function download(story: Story) {
    const blob = new Blob([JSON.stringify(story, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `taste-tales-${story.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setNotice("Your story was exported with its photo and recipe.");
  }
  return (
    <>
      <header className="site-header">
        <a href="#/" className="brand">
          <span className="brand-mark">
            <UtensilsCrossed size={23} />
          </span>
          Taste Tales<span className="brand-dot">.</span>
        </a>
        <nav
          className={menu ? "desktop-nav open" : "desktop-nav"}
          aria-label="Main navigation"
        >
          <a className={path === "/home" ? "current" : ""} href="#/home">
            Discover stories
          </a>
          <a className={explore ? "current" : ""} href="#/map">
            The food map
          </a>
          <a href="#/about">How it works</a>
        </nav>
        <button className="primary header-share" onClick={() => go("/share")}>
          <Plus size={17} />
          Share a memory
        </button>
        <button
          className="menu-button icon-button"
          aria-label="Toggle navigation"
          aria-expanded={menu}
          onClick={() => setMenu(!menu)}
        >
          {menu ? <X /> : <Menu />}
        </button>
      </header>
      {loadError && (
        <div className="warning" role="alert">
          {loadError}
        </div>
      )}
      {notice && (
        <div className="toast" role="status">
          <Check size={18} />
          {notice}
        </div>
      )}
      <main>
        {path === "/" && (
          <section className="welcome">
            <div className="welcome-copy">
              <span className="eyebrow">
                <span />A little taste of somewhere.
              </span>
              <h1>
                Every dish
                <br />
                holds a <em>story.</em>
              </h1>
              <p>
                Some flavours take us somewhere new.
                <br />
                Others bring us all the way home.
              </p>
              <p className="welcome-detail">
                Discover the people, places, and memories behind the food we
                love. And leave a little of your own.
              </p>
              <div className="hero-actions">
                <button className="primary" onClick={() => go("/about")}>
                  Begin your journey
                  <ArrowRight size={19} />
                </button>
                <button className="text-button" onClick={() => go("/home")}>
                  Take a look around
                </button>
              </div>
              <div className="welcome-note">
                <Heart size={17} />
                Made for memories, from everywhere.
              </div>
            </div>
            <div className="welcome-art">
              <div className="art-orbit orbit-one" />
              <div className="art-orbit orbit-two" />
              <div className="polaroid main-polaroid">
                <Photo src="./sinapot.jpg" alt="Golden sinapot from Nabua" />
                <span>an afternoon in Nabua ♡</span>
              </div>
              <div className="small-photo">
                <Photo src={seeds[1].image} alt="A warm bowl of noodles" />
                <span>somewhere that feels like home</span>
              </div>
              <span className="art-label">
                <MapPin size={16} />
                Nabua, Philippines
              </span>
              <span className="handwritten">Food brings us back.</span>
              <span className="spark spark-one">✳</span>
              <span className="spark spark-two">✦</span>
            </div>
          </section>
        )}
        {path === "/about" && (
          <section className="about page narrow">
            <span className="eyebrow">Pull up a chair</span>
            <h1>
              A world of stories.
              <br />
              <em>One dish at a time.</em>
            </h1>
            <p className="intro">
              You don’t need to be a writer. Start with a food you remember, and
              the person or place it brings back.
            </p>
            <div className="how-grid">
              {[
                [
                  Camera,
                  "01",
                  "Share a food memory",
                  "A photo, a place, and a moment you want to keep. Your story belongs in your own words.",
                ],
                [
                  Compass,
                  "02",
                  "Follow your curiosity",
                  "Explore the map or browse by feeling. Find a familiar memory somewhere unexpected.",
                ],
                [
                  ChefHat,
                  "03",
                  "Bring it to your table",
                  "Read the story, discover its context, and try a recipe when the storyteller adds one.",
                ],
              ].map(([Icon, n, title, copy]) => {
                const I = Icon as typeof Camera;
                return (
                  <article key={String(n)}>
                    <span className="step-icon">
                      <I />
                    </span>
                    <span className="step-number">{String(n)}</span>
                    <h3>{String(title)}</h3>
                    <p>{String(copy)}</p>
                  </article>
                );
              })}
            </div>
            <button className="primary" onClick={() => go("/home")}>
              Start exploring
              <ArrowRight size={18} />
            </button>
            <p className="fine-print">
              Prototype: new memories are stored in this browser. Example
              stories are fictional; some imagery is illustrative.
            </p>
          </section>
        )}
        {(path === "/home" || explore) && (
          <section className="page browse">
            <div className="page-heading">
              <div>
                <span className="eyebrow">
                  {explore
                    ? "Every pin, a little piece of home"
                    : "The stories we bring to the table"}
                </span>
                <h1>
                  {explore ? (
                    <>
                      Find a taste of <em>somewhere.</em>
                    </>
                  ) : (
                    <>
                      A world of food.
                      <br />
                      <em>A world of memories.</em>
                    </>
                  )}
                </h1>
              </div>
              <div className="search-area">
                {search}
                <p>Search a dish, place, or a little bit of nostalgia.</p>
              </div>
            </div>
            <div className="browse-tools">
              {chips}
              <div className="view-switch">
                <button
                  className={!explore ? "active" : ""}
                  onClick={() => go("/home")}
                >
                  <BookOpen size={16} />
                  Stories
                </button>
                <button
                  className={explore ? "active" : ""}
                  onClick={() => go("/map")}
                >
                  <MapPin size={16} />
                  Map
                </button>
              </div>
            </div>
            {explore ? (
              <div className="map-layout">
                <FoodMap
                  stories={filtered}
                  onSelect={(id) => go("/story/" + id)}
                />
                <aside className="map-results">
                  <h2>
                    {filtered.length}{" "}
                    {filtered.length === 1 ? "memory" : "memories"} to explore
                  </h2>
                  <p className="muted">Tap a coral marker or choose a story.</p>
                  {filtered.map((s) => (
                    <button
                      className="mini-story"
                      key={s.id}
                      onClick={() => go("/story/" + s.id)}
                    >
                      <Photo src={s.image} alt="" />
                      <span>
                        <small>{s.place}</small>
                        <strong>{s.dish}</strong>
                        <span>{s.title}</span>
                      </span>
                      <ArrowRight size={17} />
                    </button>
                  ))}
                  {!filtered.length && (
                    <Empty
                      onClear={() => {
                        setQuery("");
                        setTheme("All memories");
                      }}
                    />
                  )}
                  <p className="fine-print">
                    Map tiles require an internet connection. Stories are also
                    available in this list.
                  </p>
                </aside>
              </div>
            ) : (
              <>
                {!query && theme === "All memories" && (
                  <div className="featured">
                    <button
                      className="feature-image"
                      onClick={() => go("/story/sinapot")}
                    >
                      <Photo
                        src="./sinapot.jpg"
                        alt="Sinapot, golden banana pieces from Nabua"
                      />
                      <span className="feature-stamp">
                        A taste of
                        <br />
                        <b>home</b>
                        <Heart size={22} />
                      </span>
                    </button>
                    <div className="feature-copy">
                      <span className="eyebrow">
                        Featured memory · Fictional sample
                      </span>
                      <span className="location">
                        <MapPin size={14} />
                        Nabua, Philippines
                      </span>
                      <h2>
                        An afternoon that
                        <br />
                        tastes like home.
                      </h2>
                      <p>
                        Warm sinapot. An open window. An ordinary afternoon you
                        wish you could step back into.
                      </p>
                      <button
                        className="primary"
                        onClick={() => go("/story/sinapot")}
                      >
                        Step into the story
                        <ArrowRight size={18} />
                      </button>
                      <span className="feature-foot">
                        Childhood memories / Philippines
                      </span>
                    </div>
                  </div>
                )}
                <div className="section-heading">
                  <h2>
                    {query
                      ? `Stories matching “${query}”`
                      : "From kitchens everywhere"}
                  </h2>
                  <span>{filtered.length} stories</span>
                </div>
                <div className="story-grid">
                  {filtered.map((s) => (
                    <StoryCard key={s.id} story={s} />
                  ))}
                </div>
                {!filtered.length && (
                  <Empty
                    onClear={() => {
                      setQuery("");
                      setTheme("All memories");
                    }}
                  />
                )}
                <section className="contribute-banner">
                  <span className="banner-icon">
                    <Heart size={33} />
                  </span>
                  <div>
                    <h2>Your food memory matters.</h2>
                    <p>
                      There’s a story only you can tell. We’d love to hear it.
                    </p>
                  </div>
                  <button className="primary" onClick={() => go("/share")}>
                    Share your memory
                    <Plus size={17} />
                  </button>
                </section>
              </>
            )}
          </section>
        )}
        {path === "/share" && <ShareForm onSaved={onSaved} />}
        {(path.startsWith("/story/") || path.startsWith("/recipe/")) &&
          (selected ? (
            <article className="story-page">
              <div className="story-toolbar">
                <button
                  className="text-button"
                  onClick={() =>
                    go(
                      path.startsWith("/recipe/")
                        ? "/story/" + selected.id
                        : "/home",
                    )
                  }
                >
                  <ArrowLeft size={17} />
                  {path.startsWith("/recipe/")
                    ? "Back to the story"
                    : "Back to stories"}
                </button>
                <button
                  className="text-button"
                  onClick={() => download(selected)}
                >
                  <Download size={16} />
                  Export memory
                </button>
              </div>
              {path.startsWith("/recipe/") ? (
                <RecipePage story={selected} />
              ) : (
                <>
                  <div className="story-cover">
                    <Photo src={selected.image} alt={selected.dish} />
                    <div className="cover-gradient" />
                    <div className="cover-title">
                      <span className="eyebrow">
                        {selected.theme} / {selected.place}
                      </span>
                      <h1>{selected.title}</h1>
                      <span className="cover-byline">
                        {selected.demo
                          ? "An illustrative sample memory"
                          : `A memory shared by ${selected.author}`}
                      </span>
                    </div>
                  </div>
                  <div className="story-content">
                    <aside className="story-aside">
                      <span className="eyebrow">On the table</span>
                      <h2>{selected.dish}</h2>
                      <p>
                        <MapPin size={16} />
                        {selected.place}
                      </p>
                      <button
                        className="secondary"
                        onClick={() => {
                          setQuery(selected.place);
                          setTheme("All memories");
                          go("/map");
                        }}
                      >
                        Find it on the map
                        <ArrowRight size={15} />
                      </button>
                      {selected.recipe && (
                        <button
                          className="primary"
                          onClick={() => go("/recipe/" + selected.id)}
                        >
                          <ChefHat size={17} />
                          Make this dish
                        </button>
                      )}
                    </aside>
                    <div className="story-prose">
                      {selected.body.split(/\n\s*\n/).map((p, i) => (
                        <p key={i}>{p}</p>
                      ))}
                      <div className="story-divider">✳</div>
                      <h2>A little more about the food</h2>
                      <p>{selected.culture}</p>
                      {!selected.recipe && (
                        <p className="note">
                          This story doesn’t have a recipe yet. Every household
                          has its own version.
                        </p>
                      )}
                      {selected.id === "sinapot" && (
                        <details className="art-preview">
                          <summary>
                            <Sparkles size={17} />
                            Explore the illustrated memory concept
                          </summary>
                          <img
                            src="./sinapot-scene.png"
                            alt="AI-generated watercolor concept of a Nabua food memory"
                          />
                          <p className="fine-print">
                            Previously generated concept artwork, inspired by
                            the supplied food photo. The place and story are
                            imagined. Automatic artwork generation is not
                            connected in this prototype.
                          </p>
                        </details>
                      )}
                      <div className="story-end">
                        <Heart size={24} />
                        <h3>What does this bring back for you?</h3>
                        <button
                          className="primary"
                          onClick={() => go("/share")}
                        >
                          Share your own memory
                          <ArrowRight size={16} />
                        </button>
                      </div>
                      {!selected.demo && (
                        <button
                          className="delete-link"
                          onClick={async () => {
                            if (
                              !confirm(
                                "Delete this saved memory from this browser? Export it first if you want a copy.",
                              )
                            )
                              return;
                            try {
                              await deleteStory(selected.id);
                              setSaved((s) =>
                                s.filter((x) => x.id !== selected.id),
                              );
                              go("/home");
                              setNotice("Memory deleted from this browser.");
                            } catch {
                              setNotice(
                                "Could not delete the memory. Please try again.",
                              );
                            }
                          }}
                        >
                          Delete this local memory
                        </button>
                      )}
                    </div>
                  </div>
                  <section className="page related">
                    <div className="section-heading">
                      <h2>Another place. Another memory.</h2>
                    </div>
                    <div className="story-grid">
                      {stories
                        .filter((s) => s.id !== selected.id)
                        .slice(0, 3)
                        .map((s) => (
                          <StoryCard key={s.id} story={s} />
                        ))}
                    </div>
                  </section>
                </>
              )}
            </article>
          ) : (
            <section className="page narrow">
              <h1>That memory isn’t here.</h1>
              <p>
                Local stories are only available in the browser where they were
                created.
              </p>
              <button className="primary" onClick={() => go("/home")}>
                Explore stories
              </button>
            </section>
          ))}
        {!["/", "/home", "/about", "/map", "/share"].includes(path) &&
          !path.startsWith("/story/") &&
          !path.startsWith("/recipe/") && (
            <section className="page narrow">
              <h1>Let’s find your way back.</h1>
              <button className="primary" onClick={() => go("/home")}>
                Explore stories
              </button>
            </section>
          )}
      </main>
      <footer>
        <a href="#/" className="brand">
          <UtensilsCrossed size={19} />
          Taste Tales.
        </a>
        <p>Food is a place we can return to.</p>
        <span>Prototype · Stories saved on this device</span>
      </footer>
      <nav className="mobile-nav" aria-label="Mobile navigation">
        <a href="#/home" className={path === "/home" ? "active" : ""}>
          <Home size={20} />
          Discover
        </a>
        <a href="#/map" className={explore ? "active" : ""}>
          <Compass size={20} />
          Explore
        </a>
        <a href="#/share" className={path === "/share" ? "active" : ""}>
          <Plus size={20} />
          Share
        </a>
      </nav>
    </>
  );
}
function Empty({ onClear }: { onClear: () => void }) {
  return (
    <div className="empty">
      <Search size={30} />
      <h3>No memories found just yet.</h3>
      <p>Try another place or dish, or tell the first story.</p>
      <button className="secondary" onClick={onClear}>
        Clear filters
      </button>
    </div>
  );
}
function RecipePage({ story }: { story: Story }) {
  const [checked, setChecked] = useState<number[]>([]);
  const r = story.recipe;
  if (!r)
    return (
      <section className="page narrow">
        <h1>A recipe is still to come.</h1>
        <p>The contributor hasn’t added one yet.</p>
      </section>
    );
  return (
    <section className="recipe-page">
      <div className="recipe-heading">
        <div>
          <span className="eyebrow">From the story to your kitchen</span>
          <h1>
            Make <em>{story.dish}.</em>
          </h1>
          <p>{story.place}</p>
          <div className="recipe-meta">
            <span>
              <Clock size={17} />
              {r.time || "Time not specified"}
            </span>
            <span>
              <Users size={17} />
              Serves {r.serves || "—"}
            </span>
          </div>
        </div>
        <Photo src={story.image} alt={story.dish} />
      </div>
      <p className="recipe-source">
        <BookOpen size={18} />
        {r.source}
      </p>
      <div className="recipe-columns">
        <section>
          <h2>What you’ll need</h2>
          <p className="muted">Tick ingredients as you go.</p>
          <ul className="ingredients">
            {r.ingredients.map((item, i) => (
              <li key={i}>
                <label className={checked.includes(i) ? "checked" : ""}>
                  <input
                    type="checkbox"
                    checked={checked.includes(i)}
                    onChange={() =>
                      setChecked((a) =>
                        a.includes(i) ? a.filter((n) => n !== i) : [...a, i],
                      )
                    }
                  />
                  {item}
                </label>
              </li>
            ))}
          </ul>
        </section>
        <section>
          <h2>How to make it</h2>
          <ol className="method">
            {r.steps.map((step, i) => (
              <li key={i}>
                <span>{String(i + 1).padStart(2, "0")}</span>
                <p>{step}</p>
              </li>
            ))}
          </ol>
          <button className="secondary" onClick={() => window.print()}>
            Print recipe
          </button>
        </section>
      </div>
    </section>
  );
}
function ShareForm({ onSaved }: { onSaved: (s: Story) => void }) {
  const [image, setImage] = useState("");
  const [uploading, setUploading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [recipe, setRecipe] = useState(false);
  const [preview, setPreview] = useState<Story | null>(null);
  useEffect(() => {
    if (!preview) return;
    const previous = document.activeElement as HTMLElement | null;
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !busy) setPreview(null);
      if (event.key !== "Tab") return;
      const controls = Array.from(
        document.querySelectorAll<HTMLElement>(
          ".preview-modal button:not(:disabled), .preview-modal [href], .preview-modal input:not(:disabled)",
        ),
      );
      const first = controls[0],
        last = controls[controls.length - 1];
      if (!first) {
        event.preventDefault();
        return;
      }
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = originalOverflow;
      document.removeEventListener("keydown", onKey);
      previous?.focus();
    };
  }, [preview, busy]);
  function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    const d = new FormData(e.currentTarget);
    const val = (n: string) => String(d.get(n) || "").trim();
    if (!image) {
      setError("Add a photo to bring your memory to life.");
      return;
    }
    if (!val("dish") || !val("title") || !val("place") || !val("body")) {
      setError("Please complete the dish, title, place, and story.");
      return;
    }
    const ingredients = val("ingredients")
      .split("\n")
      .map((x) => x.trim())
      .filter(Boolean);
    const steps = val("steps")
      .split("\n")
      .map((x) => x.trim())
      .filter(Boolean);
    if (recipe && (!ingredients.length || !steps.length || !val("source"))) {
      setError(
        "Add ingredients, steps, and the recipe source, or turn off the recipe option.",
      );
      return;
    }
    setPreview({
      id: crypto.randomUUID(),
      title: val("title"),
      dish: val("dish"),
      place: val("place"),
      author: val("author") || "A food storyteller",
      body: val("body"),
      theme: val("theme"),
      image,
      culture:
        val("culture") ||
        "The contributor has not added further background yet.",
      createdAt: new Date().toISOString(),
      ...(recipe
        ? {
            recipe: {
              time: val("time"),
              serves: val("serves"),
              ingredients,
              steps,
              source: val("source"),
            },
          }
        : {}),
    });
  }
  async function commit() {
    if (!preview) return;
    setBusy(true);
    setError("");
    try {
      await saveStory(preview);
      onSaved(preview);
    } catch {
      setError(
        "Your memory could not be saved. Your browser storage may be full or unavailable. Your form is still here—close the preview to edit or try again.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="page share-page">
      <div className="share-intro">
        <span className="eyebrow">Your seat at the table</span>
        <h1>
          Every dish carries
          <br />
          <em>a little of us.</em>
        </h1>
        <p>
          Tell us about the food that connects you to a place, a person, or a
          moment in time.
        </p>
        <div className="prompt-note">
          <Sparkles size={22} />
          <h3>Not sure where to start?</h3>
          <p>
            Who made it for you?
            <br />
            What did the room feel like?
            <br />
            What do you wish you could go back to?
          </p>
        </div>
        <p className="fine-print">
          This prototype saves to this browser only. Nothing is posted publicly.
          You can export or delete your memory after saving.
        </p>
      </div>
      <form className="share-form" onSubmit={submit}>
        <div className="form-heading">
          <h2>Share your food story</h2>
          <span>Fields marked * are required</span>
        </div>
        <label>
          Your story title *
          <input
            name="title"
            required
            maxLength={100}
            placeholder="e.g. Sunday afternoons at Lola’s"
          />
        </label>
        <div className="form-row">
          <label>
            Name of the dish *
            <input
              name="dish"
              required
              maxLength={80}
              placeholder="e.g. Sinapot"
            />
          </label>
          <label>
            Your name <span>(optional)</span>
            <input
              name="author"
              maxLength={70}
              placeholder="How should we credit you?"
            />
          </label>
        </div>
        <label>
          Where did this memory happen? *
          <input
            name="place"
            required
            maxLength={120}
            placeholder="e.g. Nabua, Camarines Sur, Philippines"
          />
          <small>
            The memory’s location, which may differ from the dish’s origin.
          </small>
        </label>
        <label>
          Your food memory *
          <textarea
            name="body"
            required
            minLength={20}
            maxLength={10000}
            rows={7}
            placeholder="Tell us the story behind this dish…"
          />
          <small>
            At least 20 characters. Your words are the heart of the story.
          </small>
        </label>
        <label>
          This memory feels like
          <select name="theme">
            {themes.slice(1).map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </label>
        <label className="upload-label">
          Add a photo *
          <span className="upload-box">
            {image ? (
              <>
                <img src={image} alt="Your selected food photo" />
                <span>Choose a different photo</span>
              </>
            ) : (
              <>
                <Camera size={30} />
                <strong>
                  {uploading ? "Preparing your photo…" : "Choose a photo"}
                </strong>
                <span>The food, the people, or the moment.</span>
                <small>JPG, PNG, or WebP · up to 12 MB</small>
              </>
            )}
            <input
              aria-label="Upload a photo"
              type="file"
              accept="image/jpeg,image/png,image/webp"
              disabled={uploading}
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                setUploading(true);
                setError("");
                try {
                  setImage(await photoData(f));
                } catch (err) {
                  setError((err as Error).message);
                } finally {
                  setUploading(false);
                }
              }}
            />
          </span>
        </label>
        <label>
          A little cultural context <span>(optional)</span>
          <textarea
            name="culture"
            rows={3}
            maxLength={3000}
            placeholder="A family tradition, a local name, or what makes your version special…"
          />
        </label>
        <label className="recipe-toggle">
          <input
            type="checkbox"
            checked={recipe}
            onChange={(e) => setRecipe(e.target.checked)}
          />
          <span>
            <strong>Add a recipe</strong>
            <small>Help someone bring your memory to their own table.</small>
          </span>
          <ChefHat size={23} />
        </label>
        {recipe && (
          <fieldset>
            <legend>Your version of the dish</legend>
            <div className="form-row">
              <label>
                Preparation and cooking time
                <input
                  name="time"
                  maxLength={70}
                  placeholder="e.g. 30 minutes"
                />
              </label>
              <label>
                Servings
                <input name="serves" maxLength={30} placeholder="e.g. 4" />
              </label>
            </div>
            <label>
              Ingredients and quantities *
              <textarea
                required
                name="ingredients"
                rows={5}
                maxLength={5000}
                placeholder="One ingredient per line"
              />
            </label>
            <label>
              Method *
              <textarea
                required
                name="steps"
                rows={6}
                maxLength={10000}
                placeholder="One step per line"
              />
            </label>
            <label>
              Recipe credit or source *
              <input
                required
                name="source"
                maxLength={500}
                placeholder="e.g. My grandmother’s recipe, shared with permission"
              />
            </label>
          </fieldset>
        )}
        {error && (
          <p role="alert" className="error">
            {error}
          </p>
        )}
        <button className="primary submit-button" disabled={uploading || busy}>
          Preview your memory
          <ArrowRight size={17} />
        </button>
        <p className="fine-print">
          Only add photos and stories you have permission to use. AI artwork is
          not automatically generated.
        </p>
      </form>
      {preview && (
        <div className="modal-scrim">
          <section
            className="preview-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="preview-title"
          >
            <button
              autoFocus
              type="button"
              className="close-modal icon-button"
              aria-label="Close preview"
              onClick={() => setPreview(null)}
              disabled={busy}
            >
              <X />
            </button>
            <Photo src={preview.image} alt={preview.dish} />
            <div className="preview-copy">
              <span className="eyebrow">Preview · saved on this device</span>
              <h2 id="preview-title">{preview.title}</h2>
              <p className="location">
                <MapPin size={15} />
                {preview.place} · {preview.dish}
              </p>
              <p className="preview-body">{preview.body}</p>
              {preview.recipe && (
                <p>
                  <ChefHat size={16} /> Recipe included
                </p>
              )}
              {error && (
                <p className="error" role="alert">
                  {error}
                </p>
              )}
              <div className="hero-actions">
                <button
                  type="button"
                  className="secondary"
                  onClick={() => setPreview(null)}
                  disabled={busy}
                >
                  Keep editing
                </button>
                <button
                  type="button"
                  className="primary"
                  disabled={busy}
                  onClick={commit}
                >
                  {busy ? "Saving…" : "Save my memory"}
                  <Check size={17} />
                </button>
              </div>
            </div>
          </section>
        </div>
      )}
    </section>
  );
}
