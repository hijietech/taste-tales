export type Recipe = {
  time: string;
  serves: string;
  ingredients: string[];
  steps: string[];
  source: string;
};
export type Story = {
  id: string;
  title: string;
  dish: string;
  place: string;
  author: string;
  theme: string;
  image: string;
  lat?: number;
  lng?: number;
  body: string;
  culture: string;
  recipe?: Recipe;
  demo?: boolean;
  createdAt?: string;
};
export const themes = [
  "All memories",
  "Childhood",
  "Family",
  "Celebrations",
  "Far from home",
];
export const seeds: Story[] = [
  {
    id: "sinapot",
    title: "An afternoon that tastes like home",
    dish: "Sinapot",
    place: "Nabua, Philippines",
    author: "Taste Tales",
    theme: "Childhood",
    image: "./sinapot.jpg",
    lat: 13.408,
    lng: 123.373,
    demo: true,
    body: "The first bite was still warm. We sat by the window, sharing sinapot while the afternoon slipped past. Outside, someone was calling to a neighbour. Inside, there was nowhere else we needed to be.\n\nI remember the golden edges, the soft banana, and the way the plate slowly emptied between conversations. It is a small moment, but one I would return to.\n\nSometimes the food we miss is really a place, a voice, or an ordinary afternoon we did not know we would want to keep.",
    culture:
      "This sample pairs sinapot with a memory set in Nabua, Camarines Sur. The food photograph was supplied by the project creator. Recipes and preparations vary between households; invite a local cook to contribute their version.",
    recipe: {
      time: "About 25 minutes",
      serves: "4",
      ingredients: [
        "6 ripe saba bananas, peeled and sliced lengthwise",
        "¾ cup all-purpose flour",
        "¼ cup cornstarch",
        "½–¾ cup water, added gradually",
        "1 tablespoon sugar (optional)",
        "A pinch of salt",
        "Cooking oil for frying",
      ],
      steps: [
        "Combine the flour, cornstarch, salt, and optional sugar. Gradually stir in enough water to make a batter that lightly coats the banana.",
        "Pat the banana pieces dry. Dip into the batter, letting excess batter drip off.",
        "Heat oil in a deep, heavy pan over medium heat. Keep the pan attended; lower coated pieces carefully into the oil in small batches.",
        "Fry until the coating is golden and the banana is tender, turning carefully as needed. Transfer to a rack to drain.",
        "Let cool slightly before eating. Adjust batter and banana thickness to suit your family’s version.",
      ],
      source:
        "Illustrative banana-fritter recipe for this prototype, not a verified Nabua family recipe. Ask the contributor to supply their own ingredients and method.",
    },
  },
  {
    id: "ramen",
    title: "The last bowl before the train",
    dish: "Midnight ramen",
    place: "Tokyo, Japan",
    author: "Taste Tales",
    theme: "Far from home",
    image:
      "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=1100&q=80",
    lat: 35.676,
    lng: 139.65,
    demo: true,
    body: "We ducked into the smallest shop on the street. Rain clung to our coats and the windows had disappeared behind steam.\n\nFor a few minutes, between the clatter of bowls and the sound of rain, a city that felt enormous became a place where I could belong.\n\nI cannot remember what we talked about. I remember that we stayed until the bowls were empty.",
    culture:
      "This fictional story explores how an everyday meal can become a memory of belonging. It does not document a particular shop or family tradition.",
  },
  {
    id: "empanadas",
    title: "Sunday, folded by hand",
    dish: "Family empanadas",
    place: "Buenos Aires, Argentina",
    author: "Taste Tales",
    theme: "Family",
    image:
      "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=1100&q=80",
    lat: -34.604,
    lng: -58.382,
    demo: true,
    body: "My first job was to press the edges. Mine were always uneven, but they went onto the tray beside everyone else’s.\n\nThere were stories at that table that only came out on Sundays. Making lunch took longer than eating it, and that was the point.",
    culture:
      "An illustrative memory about cooking together. The stock image is for atmosphere and is not a verified photograph of this dish.",
  },
  {
    id: "jollof",
    title: "There was always room for one more",
    dish: "Celebration rice",
    place: "Lagos, Nigeria",
    author: "Taste Tales",
    theme: "Celebrations",
    image:
      "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=1100&q=80",
    lat: 6.524,
    lng: 3.379,
    demo: true,
    body: "Chairs arrived from next door. Someone brought another plate. The kitchen was full before the guests were, and the music kept finding its way in.\n\nI remember being sent to call everyone to eat. No one needed asking twice.",
    culture:
      "A fictional celebration memory, with a stock food photograph used for atmosphere. A contributor can replace it with their own dish, photograph, and recipe.",
  },
];
export function filterStories(stories: Story[], query: string, theme: string) {
  const q = query.trim().toLocaleLowerCase();
  return stories.filter(
    (s) =>
      (theme === "All memories" || s.theme === theme) &&
      (!q ||
        [s.title, s.dish, s.place, s.body]
          .join(" ")
          .toLocaleLowerCase()
          .includes(q)),
  );
}
