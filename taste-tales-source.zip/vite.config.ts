import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";
export default defineConfig({
  base: "./",
  build: { assetsDir: "" },
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      includeAssets: ["icon.svg", "sinapot.jpg"],
      manifest: {
        name: "Taste Tales",
        short_name: "Taste Tales",
        description: "Food, places, and the memories between.",
        theme_color: "#c94c3b",
        background_color: "#fff1e6",
        display: "standalone",
        start_url: "./",
        scope: "./",
        icons: [
          {
            src: "icon.svg",
            sizes: "any",
            type: "image/svg+xml",
            purpose: "any",
          },
        ],
      },
      workbox: {
        globPatterns: ["**/*.{js,css,html,svg,jpg}"],
        maximumFileSizeToCacheInBytes: 5000000,
      },
    }),
  ],
});
